# Moral Of The Story TV add-on (drizzlepudge slot)
1. `git apply --3way mos.patch`  (Veo-on-fal routing, recaps, freeze/dip/flash, part + moral cards, arc movie)
2. Copy `files/` over the repo root.
3. Delete old `channels/drizzlepudge/episodes/eps_001-015.json` and `eps_016-030.json` (copies are in `channels/drizzlepudge/archive/`).
4. `python tools/validate.py` then `MOCK=1 YT_UPLOAD=0 python -m pipeline.run render drizzlepudge MOS-001`
Video: fal-ai/veo3.1/lite/image-to-video ($0.05/s with audio, existing FAL_KEY). Backup per shot: Veo 3.1 Fast.
