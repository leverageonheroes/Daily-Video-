# Daily carousel videos: The Elders Council + Wishes from the Crib
- carousel-changes.patch: run.py (carousel command), youtube.py (fixed publish time), validate.py, docs, requirements (pillow, tzdata)
- files/: new modules (pipeline/carousel.py, pipeline/images.py), 30-day content (channels/*/carousel.json),
  generator, Railway worker (tools/railway/), backup workflow (.github/workflows/carousel.yml)
