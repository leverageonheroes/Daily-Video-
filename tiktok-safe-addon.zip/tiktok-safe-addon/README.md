# TikTok-safe cast (no nationalities, no accents)
files/: new scripts + generators + carousel content + tools/upgrades/merge_scripts.py
