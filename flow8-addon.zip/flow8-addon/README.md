# Flow channels to 8 clips (64 s), two Google accounts per channel
- flow8-changes.patch: pipeline/flow.py (account labels, N clips), tools/validate.py (clip limit from channel.json), docs
- files/: replaces channels/elders/* and channels/cribcommittee/* scripts + their generators
Apply when both inboxes are empty (after today's Shorts have posted).
